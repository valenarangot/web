const API_IMG = 'https://cataas.com/cat/says/'
const API_FACTS = 'https://catfact.ninja/fact'

export const fetchFact = async () => {
  return fetch(`${API_FACTS}`)
    .then((res) => {
      if (!res.ok) {
        throw new Error('Error fetching data from API')
      }
      return res.json()
    })
    .then((data) => {
      return data
    })
}

export const fetchImg = async (text) => {
  return fetch(`${API_IMG}` + text).then((res) => {
    if (!res.ok) {
      throw new Error('Error fetching data from API')
    }
    return res.url
  })
}
