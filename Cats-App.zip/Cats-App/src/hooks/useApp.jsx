import { useCallback, useEffect, useState } from 'react'
import { fetchFact, fetchImg } from '../services/FactsFetch'
import debounce from 'just-debounce-it'

export const useApp = () => {
  const [fact, setFact] = useState('')
  const [img, setImg] = useState('')
  const [check, setCheck] = useState(true)

  const getFacts = useCallback(
    debounce(() => { /* hace un rebote cuando hay muchos llamados, controla los llamados */
      fetchFact()
        .then((fact) => setFact(fact))
        .catch((e) => console.error(e))
    }, 300 /* el 300 es del debounce */),

    []
  )

  const getImg = useCallback(
    debounce((text) => {
      fetchImg(text)
        .then((img) => { setImg(img); setCheck(true) })
        .catch((e) => console.error(e))
    }, 300),
    []
  )

  const handleUserSubmit = () => {
    getFacts()
  }

  useEffect(() => {
    if (fact !== '') {
      setCheck(false)
      const factAllSentence = fact.fact
      const first4sentences = factAllSentence.split(' ', 4)
      const first4sentencesJoined = first4sentences.join(' ')
      getImg(first4sentencesJoined)
    }
  }, [fact])

  return {
    handleUserSubmit,
    fact,
    img,
    check
  }
}
