import React from 'react'
import './header.css'

export function Header () {
  return (
    <>
      <h1 className='Title'>
        Cats Facts
      </h1>
    </>
  )
}
