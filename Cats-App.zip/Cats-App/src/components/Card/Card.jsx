import React from 'react'
import './card.css'

export function Card ({ info, catimg, handleUserSubmit }) {
  return (
    <div className='card'>
      <img src={catimg} className='imgsize' />
      <p>{info}</p>
      <button onClick={handleUserSubmit}>New Fact</button>
    </div>
  )
}
